
from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
import random
from time import sleep

def run_pressure_slave():
    block = ModbusSequentialDataBlock(0, [0]*10)
    store = ModbusSlaveContext(hr=block)
    context = ModbusServerContext(slaves={3: store}, single=False)

    def updating_writer(a):
        while True:
            pressure = random.randint(10, 50)
            store.setValues(3, 0, [pressure])
            sleep(1)

    from threading import Thread
    Thread(target=updating_writer, args=(context,)).start()

    StartTcpServer(context, address=("0.0.0.0", 5023))
