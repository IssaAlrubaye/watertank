
from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
from time import sleep

def run_io_slave():
    block = ModbusSequentialDataBlock(0, [0]*10)
    store = ModbusSlaveContext(hr=block)
    context = ModbusServerContext(slaves={4: store}, single=False)

    def updating_writer(a):
        state = 0
        while True:
            state = 1 - state
            store.setValues(3, 0, [state])
            sleep(5)

    from threading import Thread
    Thread(target=updating_writer, args=(context,)).start()

    StartTcpServer(context, address=("0.0.0.0", 5024))
