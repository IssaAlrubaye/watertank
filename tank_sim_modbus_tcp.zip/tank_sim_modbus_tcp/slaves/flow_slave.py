
from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
import random
from time import sleep

def run_flow_slave():
    block = ModbusSequentialDataBlock(0, [0]*10)
    store = ModbusSlaveContext(hr=block)
    context = ModbusServerContext(slaves={2: store}, single=False)

    def updating_writer(a):
        while True:
            flow = random.randint(5, 20)
            store.setValues(3, 0, [flow])
            sleep(1)

    from threading import Thread
    Thread(target=updating_writer, args=(context,)).start()

    StartTcpServer(context, address=("0.0.0.0", 5022))
