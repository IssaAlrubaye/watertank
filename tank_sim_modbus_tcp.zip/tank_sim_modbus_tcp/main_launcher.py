
from slaves.level_slave import run_level_slave
from slaves.flow_slave import run_flow_slave
from slaves.pressure_slave import run_pressure_slave
from slaves.io_slave import run_io_slave
from multiprocessing import Process

if __name__ == "__main__":
    slaves = [
        Process(target=run_level_slave),
        Process(target=run_flow_slave),
        Process(target=run_pressure_slave),
        Process(target=run_io_slave),
    ]
    for p in slaves:
        p.start()
    for p in slaves:
        p.join()
