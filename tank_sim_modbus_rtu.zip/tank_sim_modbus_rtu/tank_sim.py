import random

class TankSimulator:
    def __init__(self):
        self.fullness = 0.5
        self.pump_on = False
        self.valve_in = True
        self.valve_out = False
        self.manual_override = False
        self.start_button = False
        self.stop_button = False

    def tick(self):
        if self.pump_on and self.valve_in:
            self.fullness += random.uniform(0.01, 0.05)
        if self.valve_out:
            self.fullness -= random.uniform(0.01, 0.03)

        if self.fullness > 1.0:
            self.fullness = 1.0
        if self.fullness < 0.0:
            self.fullness = 0.0
