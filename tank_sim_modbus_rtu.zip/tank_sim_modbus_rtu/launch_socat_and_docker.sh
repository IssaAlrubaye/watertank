#!/bin/bash

NUM_SLAVES=5

# Create virtual serial ports
PORT_MOUNTS=""
for i in $(seq 1 $NUM_SLAVES); do
  HOST_PORT="/tmp/ttyHOST$i"
  DOCKER_PORT="/tmp/ttyDOCKER$i"
  socat -d -d PTY,link=$HOST_PORT,mode=666 PTY,link=$DOCKER_PORT,mode=666 &
  sleep 0.5
  PORT_MOUNTS="$PORT_MOUNTS -v $DOCKER_PORT:/dev/ttyUSB$((i-1))"
done

docker build -t tank-sim .

eval "docker run -it --rm --privileged $PORT_MOUNTS tank-sim"
