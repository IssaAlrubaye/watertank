from tank_sim import TankSimulator
from slaves.level_slave import run_level_slave
from slaves.flow_slave import run_flow_slave
from slaves.pressure_slave import run_pressure_slave
from slaves.inputs_slave import run_inputs_slave
from slaves.outputs_slave import run_outputs_slave
import multiprocessing
import time

if __name__ == "__main__":
    tank = TankSimulator()

    processes = [
        multiprocessing.Process(target=run_level_slave, args=(tank, "/dev/ttyUSB0")),
        multiprocessing.Process(target=run_flow_slave, args=(tank, "/dev/ttyUSB1")),
        multiprocessing.Process(target=run_pressure_slave, args=(tank, "/dev/ttyUSB2")),
        multiprocessing.Process(target=run_inputs_slave, args=(tank, "/dev/ttyUSB3")),
        multiprocessing.Process(target=run_outputs_slave, args=(tank, "/dev/ttyUSB4")),
    ]

    for p in processes:
        p.start()

    try:
        while True:
            tank.tick()
            time.sleep(1)
    except KeyboardInterrupt:
        for p in processes:
            p.terminate()
