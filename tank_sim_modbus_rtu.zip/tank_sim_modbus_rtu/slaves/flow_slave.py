from pymodbus.server.sync import StartSerialServer
from pymodbus.device import ModbusDeviceIdentification
from pymodbus.datastore import ModbusSequentialDataBlock, ModbusSlaveContext, ModbusServerContext
import time

def run_flow_slave(tank, port):
    block = ModbusSequentialDataBlock(0, [0]*10)
    context = ModbusSlaveContext(di=block, co=block, hr=block, ir=block)
    server_context = ModbusServerContext(slaves=context, single=True)

    def updating_writer(a):
        while True:
            value = random.uniform(0.1, 0.3) if tank.pump_on else 0
            context.setValues(3, 0, [int(value * 1000)])
            time.sleep(1)

    import threading
    thread = threading.Thread(target=updating_writer, args=(server_context,))
    thread.daemon = True
    thread.start()

    StartSerialServer(context, port=port, baudrate=9600, stopbits=1, bytesize=8, parity='N')
